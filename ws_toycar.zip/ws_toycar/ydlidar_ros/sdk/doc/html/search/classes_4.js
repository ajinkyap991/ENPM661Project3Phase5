var searchData=
[
  ['keyorder',['KeyOrder',['../struct_c_simple_ini_templ_1_1_entry_1_1_key_order.html',1,'CSimpleIniTempl::Entry']]]
];
