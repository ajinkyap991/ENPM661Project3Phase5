var searchData=
[
  ['stopbits_5ft',['stopbits_t',['../namespaceserial.html#af5b116611d6628a3aa8f788fdc09f469',1,'serial']]]
];
