import rospy
from std_msgs.msg import Float64
from controller_manager_msgs.srv import SwitchController


rospy.wait_for_service('/toycar/controller_manager/switch_controller')
def talker():

    pub1 = rospy.Publisher('/toycar/joint_1_velocity_controller/command', Float64, queue_size=10)
    pub2 = rospy.Publisher('/toycar/joint_2_velocity_controller/command', Float64, queue_size=10)
    pub3 = rospy.Publisher('/toycar/joint_1_controller/command', Float64, queue_size=10)
    pub4 = rospy.Publisher('/toycar/joint_4_controller/command', Float64, queue_size=10)
    pub5 = rospy.Publisher('/toycar/joint_5_controller/command', Float64, queue_size=10)


    rospy.init_node('toycar_talker', anonymous=True)
    rate = rospy.Rate(10)

    while not rospy.is_shutdown():
        vel = 1.0
	rospy.loginfo(vel)
        pub1.publish(vel)
        pub2.publish(vel)
        pub3.publish(vel)
        pub4.publish(-0.28)
        pub5.publish(-0.28)
        
        rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
